<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Insert title here</title>
</head>
<body>
<form action="doAction6.php" method="post" enctype="multipart/form-data">
请选择您要上传的文件：<input type="file" name='myFile1' />
<input type="submit" value="上传文件" />
</form>
</body>
</html>